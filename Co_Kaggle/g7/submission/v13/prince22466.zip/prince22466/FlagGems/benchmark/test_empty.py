# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch

from . import base, consts


def empty_input_fn(shape, dtype, device):
    yield shape


def empty_permuted_input_fn(shape, dtype, device):
    # Reverse the physical layout so the allocation exercises a non-contiguous
    # memory ordering rather than the plain contiguous one.
    yield shape, list(reversed(range(len(shape))))


@pytest.mark.empty_permuted
def test_empty_permuted():
    bench = base.GenericBenchmark(
        op_name="empty_permuted",
        torch_op=torch.empty_permuted,
        dtypes=consts.FLOAT_DTYPES,
        input_fn=empty_permuted_input_fn,
    )
    bench.run()


@pytest.mark.empty
def test_empty():
    bench = base.GenericBenchmark(
        op_name="empty",
        torch_op=torch.empty,
        dtypes=consts.FLOAT_DTYPES,
        input_fn=empty_input_fn,
    )
    bench.run()
