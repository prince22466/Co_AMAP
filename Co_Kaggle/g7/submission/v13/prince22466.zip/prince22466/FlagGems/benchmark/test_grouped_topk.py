# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch

import flag_gems

from . import base, utils

try:
    from vllm._custom_ops import grouped_topk as vllm_grouped_topk

    HAS_VLLM = True
except (ImportError, AttributeError):
    HAS_VLLM = False

vendor_name = flag_gems.vendor_name


class GroupedTopKBenchmark(base.Benchmark):
    def __init__(
        self,
        op_name,
        torch_op,
        dtypes,
        renormalize=True,
        routed_scaling_factor=1.0,
        scoring_func=0,
    ):
        super().__init__(op_name=op_name, torch_op=torch_op, dtypes=dtypes)
        self.renormalize = renormalize
        self.routed_scaling_factor = routed_scaling_factor
        self.scoring_func = scoring_func

    def set_shapes(self, shape_file_path=None):
        grouped_topk_configs = [
            (1, 64, 8, 2, 8),
            (8, 64, 8, 2, 8),
            (32, 64, 8, 2, 8),
            (64, 64, 8, 2, 8),
            (128, 64, 8, 2, 8),
            (256, 64, 8, 2, 8),
            (32, 128, 8, 2, 8),
            (64, 128, 8, 2, 8),
            (128, 128, 8, 2, 8),
            (64, 64, 4, 2, 4),
            (64, 128, 16, 2, 8),
            (512, 64, 8, 2, 8),
            (1024, 64, 8, 2, 8),
            (2048, 64, 8, 2, 8),
        ]
        self.shapes = grouped_topk_configs

    def get_input_iter(self, dtype):
        for config in self.shapes:
            yield from self.grouped_topk_input_fn(config, dtype, self.device)

    def grouped_topk_input_fn(self, config, dtype, device):
        num_tokens, num_experts, n_group, topk_group, topk = config

        scores = torch.randn(num_tokens, num_experts, device=device, dtype=dtype)
        bias = torch.randn(num_experts, device=device, dtype=dtype)

        yield (
            scores,
            n_group,
            topk_group,
            topk,
            self.renormalize,
            self.routed_scaling_factor,
            bias,
            self.scoring_func,
        )


@pytest.mark.grouped_topk
@pytest.mark.skipif(not HAS_VLLM, reason="Skipped due to missing vLLM grouped_topk")
@pytest.mark.skipif(
    utils.SkipVersion("vllm", "<0.9"),
    reason="The version prior to 0.9 does not include the grouped_topk kernel.",
)
@pytest.mark.skipif(
    utils.SkipVersion("torch", "<2.7"),
    reason="The version prior to 2.7 is not compatible with VLLM.",
)
@pytest.mark.skipif(vendor_name == "metax", reason="#2891: Not working")
@pytest.mark.skipif(vendor_name == "kunlunxin", reason="#2891: Not working")
@pytest.mark.skipif(vendor_name == "iluvatar", reason="#2891: Not working")
@pytest.mark.skipif(vendor_name == "mthreads", reason="#2891: Not working")
@pytest.mark.skipif(vendor_name == "hygon", reason="#2891: RuntimeError")
@pytest.mark.skipif(flag_gems.vendor_name == "cambricon", reason="#2891: TypeError")
def test_grouped_topk_no_renorm():
    bench = GroupedTopKBenchmark(
        op_name="grouped_topk",
        torch_op=vllm_grouped_topk,
        dtypes=[torch.float32, torch.bfloat16],
        renormalize=False,
        scoring_func=0,
    )

    bench.set_gems(flag_gems.grouped_topk)
    bench.run()


@pytest.mark.grouped_topk
@pytest.mark.skipif(not HAS_VLLM, reason="Skipped due to missing vLLM grouped_topk")
@pytest.mark.skipif(
    utils.SkipVersion("vllm", "<0.9"),
    reason="The version prior to 0.9 does not include the grouped_topk kernel.",
)
@pytest.mark.skipif(
    utils.SkipVersion("torch", "<2.7"),
    reason="The version prior to 2.7 is not compatible with VLLM.",
)
@pytest.mark.skipif(vendor_name == "metax", reason="#2891: Not working")
@pytest.mark.skipif(vendor_name == "kunlunxin", reason="#2891: Not working ")
@pytest.mark.skipif(vendor_name == "iluvatar", reason="#2891: Not working")
@pytest.mark.skipif(vendor_name == "mthreads", reason="#2891: Not working")
@pytest.mark.skipif(vendor_name == "hygon", reason="#2891: RuntimeError")
@pytest.mark.skipif(flag_gems.vendor_name == "cambricon", reason="#2891: TypeError")
def test_grouped_topk_score_0():
    bench = GroupedTopKBenchmark(
        op_name="grouped_topk",
        torch_op=vllm_grouped_topk,
        dtypes=[torch.float32, torch.bfloat16],
        renormalize=True,
        scoring_func=0,
    )

    bench.set_gems(flag_gems.grouped_topk)
    bench.run()


@pytest.mark.grouped_topk
@pytest.mark.skipif(not HAS_VLLM, reason="Skipped due to missing vLLM grouped_topk")
@pytest.mark.skipif(
    utils.SkipVersion("vllm", "<0.9"),
    reason="The version prior to 0.9 does not include the grouped_topk kernel.",
)
@pytest.mark.skipif(
    utils.SkipVersion("torch", "<2.7"),
    reason="The version prior to 2.7 is not compatible with VLLM.",
)
@pytest.mark.skipif(vendor_name == "metax", reason="#2891: Not working")
@pytest.mark.skipif(vendor_name == "kunlunxin", reason="#2891: Not working")
@pytest.mark.skipif(vendor_name == "iluvatar", reason="#2891: Not working")
@pytest.mark.skipif(vendor_name == "mthreads", reason="#2891: Not working")
@pytest.mark.skipif(vendor_name == "hygon", reason="#2891: RuntimeError")
@pytest.mark.skipif(flag_gems.vendor_name == "cambricon", reason="#2891: TypeError")
def test_grouped_topk_score_1():
    bench = GroupedTopKBenchmark(
        op_name="grouped_topk",
        torch_op=vllm_grouped_topk,
        dtypes=[torch.float32, torch.bfloat16],
        renormalize=True,
        scoring_func=1,
    )

    bench.set_gems(flag_gems.grouped_topk)
    bench.run()
