# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch

import flag_gems

from . import base, consts


def input_fn(shape, cur_dtype, device):
    self = torch.randn(shape, dtype=cur_dtype, device=device)
    p = 0.5
    yield self, p


@pytest.mark.geometric_
@pytest.mark.skipif(
    flag_gems.vendor_name == "tsingmicro", reason="Issue #4131: not working"
)
def test_geometric_inplace():
    bench = base.GenericBenchmark(
        op_name="geometric_",
        input_fn=input_fn,
        torch_op=torch.Tensor.geometric_,
        dtypes=consts.FLOAT_DTYPES,
    )
    bench.run()


@pytest.mark.geometric
@pytest.mark.skipif(
    flag_gems.vendor_name == "tsingmicro", reason="Issue #4131: not working"
)
def test_geometric():
    bench = base.GenericBenchmark(
        op_name="geometric",
        input_fn=input_fn,
        torch_op=torch.ops.aten.geometric,
        dtypes=consts.FLOAT_DTYPES,
    )
    bench.run()
