# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np
import pytest
import torch

import flag_gems

from . import base, consts


def gen_indices_bool(input_shape, indices_shape, accumulate, is_bool):
    indices = []

    if is_bool:
        mask_shape = indices_shape[0]

        mask = torch.randint(
            0, 2, size=mask_shape, dtype=torch.bool, device=flag_gems.device
        )
        return [mask]

    else:
        for i, shape in enumerate(indices_shape):
            index = np.random.choice(
                np.arange(input_shape[i]), size=shape, replace=accumulate
            )
            indices.append(torch.tensor(index, device=flag_gems.device))
        return indices


def index_put_input_fn(accumulate):
    def inner(shapes, dtype, device):
        input_shape, indices_shape, values_shape, is_bool = shapes
        inp = torch.randn(
            input_shape, dtype=dtype, device=flag_gems.device, requires_grad=False
        )

        indices = gen_indices_bool(input_shape, indices_shape, accumulate, is_bool)

        if is_bool:
            K = indices[0].sum().item()
            values = torch.randn(
                (K,), dtype=dtype, device=flag_gems.device, requires_grad=False
            )
        else:
            values = torch.randn(
                values_shape, dtype=dtype, device=flag_gems.device, requires_grad=False
            )
        yield inp, indices, values, accumulate

    return inner


class IndexPutAccFalseBenchmark(base.GenericBenchmark):
    def set_more_shapes(self):
        INDEX_PUT_SHAPE = (
            ((2**28,), ((2**16,),), (2**16,), False),
            ((32, 32), ((8,), (8,)), (8,), False),
            ((32, 32), ((8,), (2, 8)), (8,), False),
            ((32, 32), ((2, 8),), (32,), False),
            ((1024, 1024), ((64,), (64,)), (64,), False),
            (
                (1024, 1024),
                (
                    (64,),
                    (
                        4,
                        64,
                    ),
                ),
                (64,),
                False,
            ),
            (
                (1024, 1024),
                (
                    (
                        4,
                        64,
                    ),
                ),
                (1024,),
                False,
            ),
            ((512, 512, 512), ((128,), (128,), (128,)), (128,), False),
            ((512, 512, 512), ((2, 128), (128,), (128,)), (128,), False),
            ((512, 512, 512), ((2, 128),), (512,), False),
            ((100,), ((100,),), (100,), True),
            ((32, 32), ((32, 32),), (32, 32), True),
            ((16, 16, 4), ((16, 16, 4),), (16, 16, 4), True),
            ((1024, 1024), ((1024, 1024),), (1024 * 1024,), True),
        )
        self.shapes = INDEX_PUT_SHAPE
        return None


@pytest.mark.index_put
@pytest.mark.skipif(
    flag_gems.vendor_name == "tsingmicro", reason="Issue #4131: not working"
)
def test_index_put_acc_false():
    bench = IndexPutAccFalseBenchmark(
        op_name="index_put",
        torch_op=torch.index_put,
        input_fn=index_put_input_fn(False),
        dtypes=consts.FLOAT_DTYPES,
    )
    bench.run()


@pytest.mark.index_put_
@pytest.mark.skipif(
    flag_gems.vendor_name == "tsingmicro", reason="Issue #4131: not working"
)
def test_index_put__acc_false():
    bench = IndexPutAccFalseBenchmark(
        op_name="index_put_",
        torch_op=torch.index_put_,
        input_fn=index_put_input_fn(False),
        dtypes=consts.FLOAT_DTYPES,
    )
    bench.run()


class IndexPutAccTrueBenchmark(base.GenericBenchmark):
    def set_more_shapes(self):
        INDEX_PUT_SHAPE = (
            ((2**28,), ((2**16,),), (2**16,), False),
            ((32, 32), ((8,), (8,)), (8,), False),
            ((1024, 1024), ((64,), (64,)), (64,), False),
            ((512, 512, 512), ((128,), (128,), (128,)), (128,), False),
            ((512, 512, 512), ((2, 128), (2, 128), (2, 128)), (2, 128), False),
            ((512, 512), ((512, 512),), (512 * 512,), True),
            ((64, 64, 64), ((64, 64, 64),), (64**3,), True),
        )
        self.shapes = INDEX_PUT_SHAPE

        return None


@pytest.mark.index_put
@pytest.mark.skipif(
    flag_gems.vendor_name == "tsingmicro", reason="Issue #4131: not working"
)
def test_index_put_acc_true():
    bench = IndexPutAccTrueBenchmark(
        op_name="index_put",
        torch_op=torch.index_put,
        input_fn=index_put_input_fn(True),
        dtypes=[torch.float16, torch.float32],
    )
    bench.run()


@pytest.mark.index_put_
@pytest.mark.skipif(
    flag_gems.vendor_name == "tsingmicro", reason="Issue #4131: not working"
)
def test_index_put__acc_true():
    bench = IndexPutAccTrueBenchmark(
        op_name="index_put_",
        torch_op=torch.index_put_,
        input_fn=index_put_input_fn(True),
        dtypes=[torch.float16, torch.float32],
    )
    bench.run()
