# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math

import pytest
import torch

from . import base, consts


# TODO(Qiming): Extract this to a base class
class NormBenchmark(base.GenericBenchmark):
    # TODO: add new metric

    def set_more_shapes(self):
        return [
            # 3D shapes represented as [batch_size, channels, hidden_size]
            (16, 16, 64),
            (16, 16, 1024),
            (16, 16, 4098),
            # 4D shapes represented as [batch_size, channels, H, W]
            (1, 8, 4, 4),
            (16, 8, 128, 128),
        ]


def group_norm_input_fn(shape, dtype, device):
    inp = torch.randn(shape, dtype=dtype, device=device)
    channel = shape[1]
    weight = torch.randn(
        [
            channel,
        ],
        dtype=dtype,
        device=device,
    )
    bias = torch.randn(
        [
            channel,
        ],
        dtype=dtype,
        device=device,
    )
    yield inp, channel // 2, weight, bias

    if base.Config.bench_level == consts.BenchLevel.COMPREHENSIVE:
        yield inp, channel, weight, bias


def native_group_norm_input_fn(shape, dtype, device):
    inp = torch.randn(shape, dtype=dtype, device=device)
    channel_count = shape[1]
    weight = torch.randn(channel_count, dtype=dtype, device=device)
    bias = torch.randn(channel_count, dtype=dtype, device=device)
    yield (
        inp,
        weight,
        bias,
        shape[0],
        channel_count,
        math.prod(shape[2:]),
        channel_count // 2,
        1e-5,
    )


@pytest.mark.native_group_norm
def test_native_group_norm():
    bench = NormBenchmark(
        input_fn=native_group_norm_input_fn,
        op_name="native_group_norm",
        torch_op=torch.ops.aten.native_group_norm.default,
        dtypes=consts.FLOAT_DTYPES,
    )
    bench.run()


@pytest.mark.group_norm
def test_group_norm():
    bench = NormBenchmark(
        input_fn=group_norm_input_fn,
        op_name="group_norm",
        torch_op=torch.nn.functional.group_norm,
        dtypes=consts.FLOAT_DTYPES,
    )
    bench.run()
