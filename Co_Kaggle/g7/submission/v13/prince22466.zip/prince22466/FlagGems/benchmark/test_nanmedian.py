# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch

import flag_gems

from . import base, consts

pytestmark = pytest.mark.skipif(
    flag_gems.vendor_name == "kunlunxin",
    reason="Issue #4253: nanmedian accuracy failure on Kunlunxin",
)

ASCEND_UNSUPPORTED_REFERENCE_DTYPES = (torch.bfloat16, torch.float64)


def _filter_reference_supported(dtypes):
    if flag_gems.vendor_name == "ascend":
        return [
            dtype
            for dtype in dtypes
            if dtype not in ASCEND_UNSUPPORTED_REFERENCE_DTYPES
        ]
    return dtypes


NANMEDIAN_DTYPES = _filter_reference_supported(
    consts.FLOAT_DTYPES
    + [
        torch.int8,
        torch.int16,
        torch.int32,
        torch.uint8,
    ]
)


def _make_input(shape, dtype, device):
    if dtype is torch.uint8:
        return torch.randint(0, 101, shape, dtype=dtype, device="cpu").to(device)
    if dtype in (torch.int8, torch.int16, torch.int32):
        return torch.randint(-100, 101, shape, dtype=dtype, device="cpu").to(device)
    inp = torch.randn(shape, dtype=dtype, device=device)
    if inp.numel() > 0:
        inp.reshape(-1)[::17] = float("nan")
    return inp


def _input_fn(shape, dtype, device):
    inp = _make_input(shape, dtype, device)
    yield (inp,)


def _out_input_fn(shape, dtype, device):
    inp = _make_input(shape, dtype, device)
    out = torch.empty((), dtype=dtype, device=device)
    yield inp, {"out": out}


def _dim_input_fn(shape, dtype, device):
    inp = _make_input(shape, dtype, device)
    if len(shape) > 1:
        yield inp, {"dim": -1}


def _dim_values_input_fn(shape, dtype, device):
    inp = _make_input(shape, dtype, device)
    if len(shape) > 1:
        out_shape = shape[:-1]
        out_values = torch.empty(out_shape, dtype=dtype, device=device)
        out_indices = torch.empty(out_shape, dtype=torch.long, device=device)
        yield inp, {"dim": -1, "out": (out_values, out_indices)}


@pytest.mark.nanmedian
def test_nanmedian():
    bench = base.GenericBenchmark(
        input_fn=_input_fn,
        op_name="nanmedian",
        torch_op=torch.nanmedian,
        dtypes=NANMEDIAN_DTYPES,
    )

    bench.run()


@pytest.mark.nanmedian_out
def test_nanmedian_out():
    bench = base.GenericBenchmark(
        input_fn=_out_input_fn,
        op_name="nanmedian_out",
        torch_op=torch.ops.aten.nanmedian.out,
        dtypes=NANMEDIAN_DTYPES,
    )

    bench.run()


@pytest.mark.nanmedian_dim
def test_nanmedian_dim():
    bench = base.GenericBenchmark(
        input_fn=_dim_input_fn,
        op_name="nanmedian_dim",
        torch_op=torch.nanmedian,
        dtypes=NANMEDIAN_DTYPES,
    )

    bench.run()


@pytest.mark.nanmedian_dim_values
def test_nanmedian_dim_values():
    bench = base.GenericBenchmark(
        input_fn=_dim_values_input_fn,
        op_name="nanmedian_dim_values",
        torch_op=torch.nanmedian,
        dtypes=NANMEDIAN_DTYPES,
    )

    bench.run()
