# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch

from . import base, consts


@pytest.mark.arccos
def test_arccos():
    bench = base.UnaryPointwiseBenchmark(
        op_name="arccos",
        torch_op=torch.arccos,
        dtypes=consts.FLOAT_DTYPES,
    )
    bench.run()


@pytest.mark.arccos_
def test_arccos_():
    bench = base.UnaryPointwiseBenchmark(
        op_name="arccos_",
        torch_op=torch.arccos_,
        dtypes=consts.FLOAT_DTYPES,
        is_inplace=True,
    )
    bench.run()
