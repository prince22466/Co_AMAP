# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch

from . import base, consts, utils


def _input_fn(shape, dtype, device):
    inp = utils.generate_tensor_input(shape, dtype, device)
    # alpha_dropout takes (input, p, train) — p defaults to 0.5
    yield inp, 0.5, True


@pytest.mark.alpha_dropout
def test_alpha_dropout():
    bench = base.GenericBenchmarkExcluse1D(
        input_fn=_input_fn,
        op_name="alpha_dropout",
        torch_op=torch.alpha_dropout,
        dtypes=consts.FLOAT_DTYPES,
    )
    bench.run()
