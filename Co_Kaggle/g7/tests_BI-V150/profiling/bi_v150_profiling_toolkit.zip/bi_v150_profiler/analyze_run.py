#!/usr/bin/env python3
"""Summarize vLLM runtime telemetry; counters and gauges kept distinct."""
import argparse, collections, json, math, statistics

def select(metrics, prefix):
    # metric names may be labeled by model_name, engine, etc.
    return [v for k,v in metrics.items() if k.split('{')[0] in (prefix,prefix.replace(':','_'))]

def aggregate(rows, prefix, mode='sum'):
    vals=[]
    for row in rows:
        samples=select(row.get('metrics',{}),prefix)
        if samples:
            vals.append((row['elapsed_s'],(max(samples) if mode=='max' else sum(samples))))
    return vals

def stats(values):
    if not values: return None
    vals=sorted(values)
    return {'mean':round(statistics.mean(vals),3),'max':round(max(vals),3),
            'p95':round(vals[math.ceil(.95*len(vals))-1],3),'samples':len(vals)}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('timeline')
    ap.add_argument('--bench-json',help='Original (UNMODIFIED) vllm bench --save-result JSON')
    ap.add_argument('--out')
    args=ap.parse_args()
    rows=[json.loads(x) for x in open(args.timeline,encoding='utf8') if x.strip()]
    result={'samples':len(rows),'duration_s':rows[-1]['elapsed_s']-rows[0]['elapsed_s'] if len(rows)>1 else 0,
            'errors':sum('metrics_error' in x for x in rows),'observed_metrics':sorted({k.split('{')[0] for row in rows for k in row.get('metrics',{})})}
    for key in ('vllm:num_requests_running','vllm:num_requests_waiting',
                'vllm:gpu_cache_usage_perc','vllm:kv_cache_usage_perc',
                'vllm:gpu_prefix_cache_hit_rate','vllm:cpu_cache_usage_perc'):
        vals=aggregate(rows,key)
        if vals:result[key]=stats([v for _,v in vals])
    for key in ('vllm:num_preemptions_total','vllm:preemption_total','vllm:request_success_total'):
        vals=aggregate(rows,key)
        if len(vals)>1:
            # Labels can appear and disappear; clamp negative reset intervals instead of false counter decrease.
            result[key+'_delta']={'first':vals[0][1], 'last':vals[-1][1],
              'net_delta':vals[-1][1]-vals[0][1], 'possible_reset':any(b<a for (_,a),(_,b) in zip(vals,vals[1:]))}
    for k in ('gpu_util_percent','memory_used_mib'):
        values=[r.get('gpu',{}).get(k) for r in rows]
        result[k]=stats([v for v in values if isinstance(v,(int,float))])
    if args.bench_json:
        b=json.load(open(args.bench_json,encoding='utf8'))
        result['original_benchmark']={k:b.get(k) for k in ('num_prompts','max_concurrency','duration','completed','failed','total_input_tokens','total_output_tokens','output_throughput','total_token_throughput','mean_ttft_ms','mean_tpot_ms','p99_ttft_ms') if k in b}
        if b.get('duration') and b.get('total_input_tokens') is not None:
            result['original_benchmark']['input_token_throughput']=b['total_input_tokens']/b['duration']
    hints=[]
    w=result.get('vllm:num_requests_waiting')
    if w and w['p95']>0: hints.append('Waiting requests observed: inspect scheduler capacity / KV cache and preemption before assuming GPU kernels are sole bottleneck.')
    usage=result.get('vllm:gpu_cache_usage_perc') or result.get('vllm:kv_cache_usage_perc')
    if usage and usage['p95']>.9: hints.append('KV cache usage often above 90%: inspect cache capacity, preemption, and residency.')
    if any(k.endswith('_delta') and ('preempt' in k) and result[k]['net_delta']>0 for k in result):
        hints.append('Preemptions increased during run: memory pressure/scheduler overhead may suppress throughput.')
    util=result.get('gpu_util_percent')
    if util and util['mean']<45: hints.append('GPU utilization sampled below 45%: investigate CPU/scheduler stalls, memory waits, and insufficient runnable work.')
    if not any(x in result for x in ('vllm:num_requests_running','vllm:num_requests_waiting')):
        hints.append('vLLM running/waiting gauges unavailable; inspect observed_metrics and server /metrics for platform-specific names.')
    result['diagnostic_hints_not_proven_causes']=hints
    content=json.dumps(result,indent=2)
    print(content)
    if args.out:
        with open(args.out,'w',encoding='utf8') as f:f.write(content+'\n')
if __name__=='__main__':main()
