#!/usr/bin/env bash
# Passive environment capture: does not change vLLM flags or installed packages.
set -euo pipefail
OUT="${1:-./profile_runs/environment}"
mkdir -p "$OUT"
{
  date -Is
  uname -a
  cat /etc/os-release 2>/dev/null || true
  echo '--- GPU ---'
  ixsmi || true
  ixsmi -L || true
  echo '--- commands ---'
  for cmd in ixsmi ixprof ixprofiler nsys ncu perf pidstat py-spy triton vllm; do
    command -v "$cmd" || true
  done
  echo '--- Python / packages ---'
  python - <<'PY'
import sys, importlib.metadata as md, importlib.util
print(sys.version)
for n in ['torch','vllm','vllm-plugin-fl','flag_gems','flagtree','triton','transformers','psutil']:
    try: print(n, md.version(n))
    except md.PackageNotFoundError: print(n,'not installed')
for mod in ['vllm','vllm_fl','flag_gems']:
    try:
        spec = importlib.util.find_spec(mod)
        print(mod, spec.origin if spec else 'missing')
    except Exception as ex: print(mod, type(ex).__name__, ex)
PY
  echo '--- installed local revisions ---'
  for root in /workspace/vllm-plugin-FL /workspace/FlagGems /workspace/MiniCPM5-2B; do
    if [ -d "$root/.git" ]; then
      git -C "$root" log -1 --format='%H %s' || true
      git -C "$root" status --short || true
    fi
  done
  echo '--- model config (non-secret) ---'
  if [ -f /workspace/MiniCPM5-2B/config.json ]; then
    python - <<'PY'
import json
p='/workspace/MiniCPM5-2B/config.json'
d=json.load(open(p))
for k in ('model_type','architectures','num_hidden_layers','hidden_size','num_attention_heads','num_key_value_heads','head_dim','torch_dtype','max_position_embeddings'):
 print(f'{k}: {d.get(k)}')
PY
  fi
  echo '--- server process args ---'
  ps -eo pid,ppid,%cpu,%mem,etime,args | grep -E '[v]llm|[V]LLM' | head -40 || true
} > "$OUT/environment.txt" 2>&1

# Collect a bounded view of potential dispatch locations, not evidence of actual runtime calls.
{
 for p in /usr/local/lib/python3.12/site-packages/vllm_fl /usr/local/lib/python3.12/site-packages/flag_gems /workspace/vllm-plugin-FL/vllm_fl; do
   if [ -d "$p" ]; then
     echo "--- $p ---"
     find "$p" -type f \( -iname '*attention*.py' -o -iname '*paged*.py' -o -iname '*gemm*.py' -o -iname '*rmsnorm*.py' \) | head -100
   fi
 done
} > "$OUT/kernel_candidates.txt" 2>&1
printf 'Environment saved in %s\n' "$OUT"
