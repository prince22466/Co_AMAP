#!/usr/bin/env python3
"""Compare unchanged external throughput benchmark CSVs grouped by workload.
Rows with SUCCESS are averaged. Does NOT alter benchmark scripts or parameters.
"""
import argparse,csv,collections,statistics

def read(path):
    groups=collections.defaultdict(list)
    with open(path,encoding='utf8',newline='') as f:
        for r in csv.DictReader(f):
            try:
                key=(int(r['Prefill']),int(r['Decode']),int(r['Conc']))
                vals={'total':float(r['Total tok/s']),
                      'output':float(r['Output tok/s']),
                      'tpot':float(r['Mean TPOT (ms)']),
                      'ttft':float(r['Mean TTFT (ms)'])}
                if r.get('Run Status','SUCCESS') not in ('SUCCESS',''):continue
                groups[key].append(vals)
            except (ValueError,KeyError,TypeError):continue
    return groups

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('baseline_csv');p.add_argument('candidate_csv')
    p.add_argument('--drop-first',action='store_true',help='Exclude each workload first measured run symmetrically')
    a=p.parse_args();b=read(a.baseline_csv); c=read(a.candidate_csv)
    if not b or not c: p.error('No benchmark rows found; provide the two original CSV files.')
    print('workload(input/output/concurrency)   baseline_total  candidate_total  total_speedup  output_speedup  avg_TPOT_change')
    for key in sorted(b.keys() & c.keys()):
        left=b[key][int(a.drop_first):];right=c[key][int(a.drop_first):]
        if not left or not right: continue
        avg=lambda rec,k:statistics.mean(z[k] for z in rec)
        tb,tc=avg(left,'total'),avg(right,'total'); ob,oc=avg(left,'output'),avg(right,'output')
        tp_b,tp_c=avg(left,'tpot'),avg(right,'tpot')
        print(f'{key!s:34} {tb:14.2f} {tc:16.2f} {tc/tb:13.3f}x {oc/ob:14.3f}x {tp_c/tp_b-1:+17.2%}')
    for key in sorted(b.keys() ^ c.keys()):print('Unmatched workload:',key)
    print('Note: throughput gains must be verified on identical benchmark configurations; profiling traces are not substitutes.')
if __name__=='__main__':main()
