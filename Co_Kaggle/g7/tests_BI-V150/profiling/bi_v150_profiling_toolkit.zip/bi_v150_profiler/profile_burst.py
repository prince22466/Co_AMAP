#!/usr/bin/env python3
"""Short, separate diagnostic vLLM traffic around native /start_profile & /stop_profile.
Not the competition throughput benchmark. No benchmark code or model modifications.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import pathlib
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


def api(base, endpoint, payload=None, timeout=3600):
    body = None if payload is None else json.dumps(payload).encode('utf8')
    req = Request(base.rstrip('/')+endpoint, data=body, method='POST' if payload is not None else 'GET',
                  headers={'Content-Type':'application/json', 'Authorization':'Bearer EMPTY'})
    with urlopen(req, timeout=timeout) as r:
        data=r.read()
        return json.loads(data) if data else {}


def post_profile(base, endpoint, timeout):
    req = Request(base.rstrip('/')+endpoint, data=b'',method='POST')
    with urlopen(req,timeout=timeout) as r:
        return (r.status,r.read(4096).decode('utf-8','replace'))


def generate_prompt(tokenizer, target, request_id):
    # Different *early* prefixes prevent unintended prefix-cache sharing across warmup/measured runs.
    prefix=f'Unique diagnostic ID={request_id}. Analyze these independent numbered records.\n'
    lines=[]
    j=0
    # ~15-30 tokens/line, target usually 4096 or 16384.
    while len(lines) < max(100,target//10):
        digest=hashlib.sha256(f'{request_id}:{j}'.encode()).hexdigest()[:20]
        lines.append(f'Item {j}: group={digest}, value={(j*j+17)%9973}, note=check_{j%67}.\n')
        j+=1
    ids=tokenizer.encode(prefix+''.join(lines), add_special_tokens=False)
    if len(ids)<target:
        raise RuntimeError(f'prompt generator produced {len(ids)} tokens, less than {target}')
    prompt=tokenizer.decode(ids[:target], skip_special_tokens=False,
                            clean_up_tokenization_spaces=False)
    actual=len(tokenizer.encode(prompt,add_special_tokens=False))
    return prompt,actual


def one_request(base,model,prompt,output_tokens,timeout):
    t=time.monotonic()
    req={'model':model,'prompt':prompt,'max_tokens':output_tokens,'temperature':0.0,'stream':False}
    try:
        ret=api(base,'/v1/completions',req,timeout)
        txt=ret.get('choices',[{}])[0].get('text','')
        return {'ok':True,'latency_s':round(time.monotonic()-t,3),
                'usage':ret.get('usage',{}),'finish_reason':ret.get('choices',[{}])[0].get('finish_reason'),
                'visible_text_chars':len(txt)}
    except (HTTPError,URLError,TimeoutError,ValueError) as e:
        extra=''
        if isinstance(e,HTTPError): extra=e.read(1500).decode('utf-8','replace')
        return {'ok':False,'latency_s':round(time.monotonic()-t,3),'error':str(e)+' '+extra}


def burst(base,model,prompts,outlen,parallel,timeout):
    records=[None]*len(prompts)
    t=time.monotonic()
    with ThreadPoolExecutor(max_workers=parallel) as pool:
        jobs={pool.submit(one_request,base,model,p,outlen,timeout):i for i,(p,_) in enumerate(prompts)}
        for f in as_completed(jobs):records[jobs[f]]=f.result()
    return {'wall_s':round(time.monotonic()-t,3),'requests':records,
            'input_token_counts_before_server': [n for _,n in prompts],
            'successful':sum(r.get('ok',False) for r in records),
            'reported_output_tokens':sum(r.get('usage',{}).get('completion_tokens',0) for r in records)}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--base-url',default='http://127.0.0.1:8000')
    ap.add_argument('--model', default='',help='server model alias; empty to query /v1/models')
    ap.add_argument('--tokenizer',default='/workspace/MiniCPM5-2B')
    ap.add_argument('--input-tokens',type=int,required=True,help='4096 or 16384 typical')
    ap.add_argument('--output-tokens',type=int,required=True,help='1 ~ prefill; 64/128 ~ decode')
    ap.add_argument('--concurrency',type=int,default=1)
    ap.add_argument('--num-requests',type=int,default=2)
    ap.add_argument('--warmup-requests',type=int,default=1)
    ap.add_argument('--timeout',type=int,default=3600)
    ap.add_argument('--out',required=True,help='output JSON; separate from native profiler trace dir')
    a=ap.parse_args()
    if not 1<=a.concurrency<=16: ap.error('--concurrency should be 1..16 for diagnostic traces')
    if not 1<=a.num_requests<=32: ap.error('use 1..32 requests to prevent huge traces')
    if a.input_tokens<32 or a.output_tokens<1: ap.error('input/output lengths are invalid')
    outfile=pathlib.Path(a.out)
    outfile.parent.mkdir(parents=True,exist_ok=True)
    if outfile.exists(): ap.error(f'output already exists: {outfile}')
    try:
        if not a.model:
            models=api(a.base_url,'/v1/models',timeout=10)
            a.model=models['data'][0]['id']
    except Exception as e:
        ap.error(f'cannot query /v1/models: {e}; pass --model to override')
    print('Loading local tokenizer:',a.tokenizer,flush=True)
    try:
        from transformers import AutoTokenizer
        tokenizer=AutoTokenizer.from_pretrained(a.tokenizer,local_files_only=True,trust_remote_code=True)
    except Exception as e:
        ap.error('could not load local tokenizer: '+str(e))
    print('Generating diagnostic prompts; this does NOT change any benchmark dataset.',flush=True)
    warm=[generate_prompt(tokenizer,a.input_tokens,f'warm_{i}') for i in range(a.warmup_requests)]
    measured=[generate_prompt(tokenizer,a.input_tokens,f'measure_{i}') for i in range(a.num_requests)]
    report={'settings':{'base_url':a.base_url,'model':a.model,'input_tokens_target':a.input_tokens,
             'output_tokens_limit':a.output_tokens,'concurrency':a.concurrency,'num_requests':a.num_requests,
             'warmup_requests':a.warmup_requests},'note':'Diagnostic, NOT competition throughput score.'}
    if warm:
        print('Warmup (unprofiled)...',flush=True)
        report['warmup']=burst(a.base_url,a.model,warm,a.output_tokens,min(a.concurrency,len(warm)),a.timeout)
        if report['warmup']['successful']<len(warm):
            raise RuntimeError('Warmup failed; inspect server logs. No profile started. '+repr(report['warmup']))
    print('Starting native worker profiler...',flush=True)
    try:
        status,msg=post_profile(a.base_url,'/start_profile',a.timeout)
        print('start_profile:',status,msg[:150],flush=True)
    except Exception as e:
        raise RuntimeError('POST /start_profile failed. Restart with --profiler-config; no profiling was performed.') from e
    try:
        print('Executing diagnostic requests...',flush=True)
        report['measured']=burst(a.base_url,a.model,measured,a.output_tokens,a.concurrency,a.timeout)
    finally:
        # Must flush even if generation fails.
        print('Stopping and flushing profiler...',flush=True)
        try:
            status,msg=post_profile(a.base_url,'/stop_profile',a.timeout)
            report['stop_profile']={'status':status,'response':msg[:1000]}
        except Exception as e:
            report['stop_profile']={'error':repr(e)}
            print('WARNING: /stop_profile failed:',repr(e),flush=True)
    outfile.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print('Profile request report:',outfile,'success:',report.get('measured',{}).get('successful'),flush=True)

if __name__=='__main__':main()
