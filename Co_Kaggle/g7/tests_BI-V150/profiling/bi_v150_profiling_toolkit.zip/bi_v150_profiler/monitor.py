#!/usr/bin/env python3
"""Low-impact vLLM /metrics + ixsmi telemetry. Python standard library only."""
import argparse, datetime, json, re, signal, subprocess, time
from urllib.request import urlopen

STOP = False

def stop_signal(*_):
    global STOP
    STOP = True

RE_METRIC = re.compile(r'^([a-zA-Z_:][\w:]*)(?:\{([^}]*)\})?\s+([-+\d.eE]+)(?:\s|$)')
RE_GPU = re.compile(r'^\s*(\d+)\s+Iluvatar\s+(.*?)\s+\|.*')

def scrape_metrics(url):
    with urlopen(url, timeout=2.5) as reply:
        body = reply.read().decode('utf-8', 'replace')
    metrics = {}
    for line in body.splitlines():
        if not line or line.startswith('#'): continue
        m = RE_METRIC.match(line)
        if not m: continue
        name, labels, value = m.groups()
        try: v = float(value)
        except ValueError: continue
        if name.startswith(('vllm:', 'vllm_', 'process_')):
            # Keep label combinations as distinct series, not overwriting quantile/bucket values.
            key = name + ('{' + labels + '}' if labels else '')
            metrics[key] = v
    return metrics

def scrape_ixsmi():
    """Parse ixsmi's standard *two-row* GPU format, without querying undocumented APIs."""
    try:
        run=subprocess.run(['ixsmi'],capture_output=True,text=True,timeout=4)
        if run.returncode: return {'error':f'ixsmi exit {run.returncode}: {run.stderr[:100]}'}
        lines=run.stdout.splitlines()
        for i,line in enumerate(lines):
            if 'Iluvatar' not in line or 'GPU' in line: continue
            # A second row below device name contains GPU memory and utilization.
            data_row=next((l for l in lines[i+1:i+4] if 'MiB' in l),'')
            if not data_row:continue
            mem=re.search(r'(\d+)MiB\s*/\s*(\d+)MiB',data_row)
            utilization=re.search(r'\|\s*(\d+)%\s+(?:Default|Exclusive|Prohibited)',data_row)
            result={'raw_gpu_row':line.strip()+' '+data_row.strip()}
            if mem:result.update(memory_used_mib=int(mem.group(1)),memory_total_mib=int(mem.group(2)))
            if utilization:result['gpu_util_percent']=int(utilization.group(1))
            return result
        return {'warning':'No parseable two-row ixsmi GPU sample'}
    except (OSError,subprocess.TimeoutExpired) as ex:
        return {'error':str(ex)}


def sample_engine_cpu():
    try:
        run=subprocess.run(['ps','-eo','pid,pcpu,rss,args','--no-headers'],
                           capture_output=True,text=True,timeout=3)
        found=[]
        for line in run.stdout.splitlines():
            pieces=line.strip().split(None,3)
            if len(pieces)!=4:continue
            pid,cpu,rss,cmd=pieces
            low=cmd.lower()
            if any(q in low for q in ('vllm::','vllm serve','vllm_fl','enginecore')) and not any(
                    q in low for q in ('monitor.py','sample_engine_cpu','ps -eo')):
                try:found.append({'pid':int(pid),'cpu_percent':float(cpu),
                                  'resident_mib':round(int(rss)/1024,1),'cmd':cmd[:180]})
                except ValueError:pass
        return found[:20]
    except Exception:return []

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--url',default='http://127.0.0.1:8000/metrics')
    ap.add_argument('--out',required=True)
    ap.add_argument('--interval',type=float,default=2.0,help='seconds; use >=2 to avoid load')
    ap.add_argument('--ixsmi-every',type=int,default=3,help='sample ixsmi every N metrics samples')
    ap.add_argument('--duration',type=float,default=0,help='0 = until Ctrl-C')
    ap.add_argument('--process-every',type=int,default=5,help='sample serving process CPU/RSS every N samples')
    args=ap.parse_args()
    if args.interval < 1: ap.error('--interval must be >= 1 second')
    signal.signal(signal.SIGINT,stop_signal)
    signal.signal(signal.SIGTERM,stop_signal)
    start=time.monotonic(); i=0; last_gpu={}; last_proc=[]
    with open(args.out,'w',encoding='utf8',buffering=1) as f:
        while not STOP:
            tick=time.monotonic()
            row={'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_s':round(tick-start,3)}
            try: row['metrics']=scrape_metrics(args.url)
            except Exception as e: row['metrics_error']=f'{type(e).__name__}: {e}'
            if i % max(args.ixsmi_every,1)==0: last_gpu=scrape_ixsmi()
            row['gpu']=last_gpu
            if i % max(args.process_every,1)==0: last_proc=sample_engine_cpu()
            row['serving_processes']=last_proc
            f.write(json.dumps(row,allow_nan=False)+'\n')
            i+=1
            if args.duration and time.monotonic()-start >= args.duration: break
            delay=args.interval-(time.monotonic()-tick)
            if delay>0: time.sleep(delay)
    print('Wrote',i,'samples to',args.out)
if __name__=='__main__':main()
