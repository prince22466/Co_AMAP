#!/usr/bin/env python3
"""Cheap GPU profiler capability check, not an end-to-end model benchmark."""
import pathlib, sys
try:
    import torch
    from torch.profiler import profile,ProfilerActivity
    print('torch',torch.__version__,'CUDA-compatible GPU:',torch.cuda.is_available())
    if not torch.cuda.is_available(): raise RuntimeError('GPU unavailable')
    x=torch.randn((256,256),device='cuda')
    for _ in range(3): y=x@x
    torch.cuda.synchronize()
    out=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else './profiler_probe.json')
    acts=[ProfilerActivity.CPU, ProfilerActivity.CUDA]
    with profile(activities=acts,record_shapes=False,with_stack=False) as p:
        for _ in range(4):y=x@x
        torch.cuda.synchronize()
    print(p.key_averages().table(sort_by='self_cuda_time_total',row_limit=10))
    p.export_chrome_trace(str(out))
    print('Wrote:',out)
except Exception as e:
    print('PyTorch GPU profiler failed (this does not imply inference is broken):',repr(e),file=sys.stderr)
    sys.exit(2)
