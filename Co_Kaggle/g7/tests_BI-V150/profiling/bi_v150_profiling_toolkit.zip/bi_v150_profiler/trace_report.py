#!/usr/bin/env python3
"""Quick GPU-kernel rollup from native PyTorch Chrome trace (JSON / JSON.gz).
Prefer the plugin's tools/operator_profile extractor when available for detailed attribution.
"""
import argparse, collections, csv, gzip, json, pathlib, re

def category(name):
    n=name.lower()
    if re.search(r'(reshape_and_cache|cache_write|copy_blocks|swap_blocks|kv_cache|cache_kernel|gather_cache)',n):return 'KV-cache'
    if re.search(r'(flash|attention|paged_attn|flashinfer|gqa|decode_attn|fused_attn)',n):return 'Attention'
    if re.search(r'(gemm|sgemm|hgemm|matmul|mm_kernel|cutlass|cublas|linear)',n):return 'GEMM/linear'
    if re.search(r'(rms.?norm|layer.?norm|normalization)',n):return 'Norm'
    if re.search(r'(rope|rotary|rotary_embedding)',n):return 'RoPE'
    if re.search(r'(sampling|sampler|topk|top_p|multinomial|softmax)',n):return 'Sampler/softmax'
    if re.search(r'(silu|swiglu|gelu|fused_moe|activation)',n):return 'Activation/MLP'
    if re.search(r'(triton_poi|elementwise|vectorized|fused_element)',n):return 'Pointwise/fused'
    return 'Other/unattributed'

def read_events(path):
    op=gzip.open if path.suffix=='.gz' else open
    with op(path,'rt',encoding='utf8') as f: obj=json.load(f)
    return obj.get('traceEvents',[]) if isinstance(obj,dict) else obj

def is_kernel(e):
    if e.get('ph')!='X' or not isinstance(e.get('dur'),(int,float)):return False
    cat=str(e.get('cat','')).lower()
    args=e.get('args') or {}
    if isinstance(args,dict) and ('stream' in args or 'Stream' in args) and 'gpu_mem' not in cat:
        return True
    return any(x in cat for x in ('kernel','gpu_kernel')) and 'cpu' not in cat

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('trace',help='rank0....pt.trace.json[.gz]')
    ap.add_argument('--out-csv',help='write detailed kernel rollup')
    ap.add_argument('--top',type=int,default=25)
    a=ap.parse_args()
    path=pathlib.Path(a.trace)
    ev=read_events(path)
    stats=collections.defaultdict(lambda:[0,0.0])
    cats=collections.defaultdict(lambda:[0,0.0])
    cpu_count=0
    for e in ev:
        if e.get('ph')=='X' and not is_kernel(e):cpu_count+=1
        if not is_kernel(e):continue
        name=str(e.get('name') or '<unnamed>')
        dur=float(e['dur']) # Chrome trace duration in microseconds
        if dur<=0: continue
        c=category(name)
        stats[(c,name)][0]+=1;stats[(c,name)][1]+=dur
        cats[c][0]+=1;cats[c][1]+=dur
    total=sum(v[1] for v in stats.values())
    print(f'File: {path}\nTrace events: {len(ev)}; GPU kernel events: {sum(v[0] for v in stats.values())}; CPU/non-kernel spans: {cpu_count}')
    if not total:
        print('NO GPU KERNEL EVENTS. CoreX torch profiler may lack device events, or trace may not cover inference.')
        print('Use CPU schedule metrics, vendor profiler, or check server profiler config before interpreting this trace.')
        return
    print(f'Summed GPU kernel duration (NOT wall time): {total/1000:.3f} ms')
    print('\nTIME BY INFERRED KERNEL CATEGORY (name heuristics; verify exact functions)')
    for name,(calls,us) in sorted(cats.items(),key=lambda z:-z[1][1]):
        print(f'{name:22s} {us/1000:11.3f} ms {us/total*100:6.2f}% {calls:9d} calls')
    data=[]
    for (c,name),(calls,us) in sorted(stats.items(),key=lambda z:-z[1][1]):
        data.append({'class':c,'kernel':name,'calls':calls,'summed_gpu_ms':round(us/1000,4),
                     'share_of_summed_gpu_time_percent':round(100*us/total,4),
                     'avg_us':round(us/calls,3)})
    print('\nTOP GPU KERNELS:')
    for d in data[:a.top]:
        print(f'{d["summed_gpu_ms"]:10.3f} ms  {d["share_of_summed_gpu_time_percent"]:6.2f}%  '
              f'{d["calls"]:6d}x  {d["class"]:18s}  {d["kernel"][:110]}')
    if a.out_csv:
        with open(a.out_csv,'w',newline='',encoding='utf8') as f:
            w=csv.DictWriter(f,fieldnames=data[0].keys());w.writeheader();w.writerows(data)
        print('CSV saved:',a.out_csv)
    print('\nCaveat: this simple script sums kernel durations, which may overlap on GPU streams.')
    print('Use the complete trace timeline to distinguish idle gaps, overlap, and CUDA graph replays.')
if __name__=='__main__':main()
