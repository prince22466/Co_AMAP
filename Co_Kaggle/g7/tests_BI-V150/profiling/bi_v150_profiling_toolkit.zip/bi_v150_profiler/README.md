# MiniCPM5-2B / FlagOS / Iluvatar BI-V150 profiling toolkit

This is a **diagnostic toolkit**. It does not alter model hyperparameters, operator dispatch choices, the benchmark driver, quantization, or speculative decoding, and it does not merge upstream framework changes. Do not interpret profiler-enabled throughput as the competition score.

Environment observed in the project:

- Model: `/workspace/MiniCPM5-2B`; local tokenizer at the same path.
- Serving: vLLM `0.24.0+empty` + `vllm-plugin-fl 0.3.0rc0`, FlagGems `5.3.5`, CoreX torch `2.10.0+corex.4.5.0`.
- GPU: single Iluvatar BI-V150, 32 GiB.
- Baseline reported in `run_4k16K_benchmark.txt`: 4K/1K/64 ~1881.95 **total** tok/s and 376.39 output tok/s; 16K/1K/64 ~861.88 total tok/s and 50.70 output tok/s. These are the published summary statistics, not measurements produced by this toolkit.

## A. Read-only baseline, before restarting anything

Copy the unpacked `bi_v150_profiler` folder to the BI-V150 host (for example `/root/bi_v150_profiler`).

```bash
cd /root/bi_v150_profiler
mkdir -p profile_runs
bash collect_env.sh profile_runs/environment
bash locate_kernels.sh profile_runs/dispatch_candidates.txt
# Look at available profiler support. Safe and small (256x256 GPU matmul).
python probe_torch_profiler.py profile_runs/probe_trace.json
python trace_report.py profile_runs/probe_trace.json --top 10
```

`probe_torch_profiler.py` **must not** be used to estimate the model's end-to-end performance. A successful probe confirms trace collection in this particular torch/CoreX build; it does not guarantee useful worker trace attribution.

If the probe reports no GPU kernel events, check CoreX's supported profiler tools with `command -v ...` in `environment.txt`. Do not install NVIDIA-specific profilers by assumption: CoreX presents a CUDA-compatible API, but that does not guarantee CUPTI/Nsight compatibility.

## B. Low-overhead service telemetry (use with the original benchmark)

**Terminal 1**: let the EXISTING vLLM server run normally, without profiler. Capture runtime state:

```bash
python monitor.py \
  --url http://127.0.0.1:8000/metrics \
  --out profile_runs/official_4k_timeline.jsonl \
  --interval 2 --ixsmi-every 3 &
MONITOR_PID=$!
```

**Terminal 2**: execute the *exact pre-existing* official 4K workload benchmark command. Do NOT modify its script, arrival schedule, request count, input/output lengths, or concurrency for score comparisons. Repeat for 16K with separate telemetry output. After benchmark finishes:

```bash
kill -TERM "$MONITOR_PID"  # clean exit; SIGTERM is handled by monitor.py
wait "$MONITOR_PID" || true
python analyze_run.py profile_runs/official_4k_timeline.jsonl \
  --out profile_runs/official_4k_analysis.json
```

For a benchmark that produces standard `vllm bench serve --save-result` JSON, add `--bench-json /path/to/unmodified_result.json` to `analyze_run.py`. For benchmarks producing only CSV, keep the existing summary CSV; this analyzer does not fabricate token throughput from telemetry.

Useful observations:

- High running AND waiting requests with a near-full KV cache / preemption counter increments -> scheduling / KV memory residency suspicion.
- High waiting, low GPU utilization -> scheduler or stalls; correlate with worker process CPU load.
- Busy GPU without waiting -> kernel/memory efficiency likely worth attention.
- Very long TTFT but steady TPOT -> prefill or queueing; separate those using traces and the scheduler metrics.

Metric availability varies by vLLM version. The summary explicitly lists observed series and marks missing signals. `ixsmi` human-readable GPU utilization is a coarse sample, not precise kernel occupancy or HBM bandwidth. Telemetry introduces some overhead: re-run score benchmarks **without** telemetry for the authoritative numbers.

## C. Enable native GPU operator trace (restart the SAME vLLM launch with one extra profiling flag)

**Do not copy a guessed server configuration.** Retrieve the exact baseline launch command from your shell history, start script, or logs and leave the model/runtime configuration unchanged. Stop the existing server; append only this diagnostic profiling flag:

```bash
mkdir -p /root/bi_v150_profiler/profile_runs/native_torch
# Example flag to append to your existing `vllm serve ...` command:
--profiler-config '{"profiler":"torch","torch_profiler_dir":"/root/bi_v150_profiler/profile_runs/native_torch","torch_profiler_record_shapes":true,"torch_profiler_with_stack":false,"torch_profiler_with_memory":false,"torch_profiler_dump_cuda_time_total":true,"ignore_frontend":true}'
```

**The standalone `--profiler-config` line above is a flag, not a shell command.** For example, the completed command will have this shape (replace all other args with your **actual baseline args**):

```bash
vllm serve /workspace/MiniCPM5-2B \
  --served-model-name MiniCPM5-2B \
  --port 8000 \
  [YOUR_UNCHANGED_BASELINE_SERVING_FLAGS] \
  --profiler-config '{"profiler":"torch","torch_profiler_dir":"/root/bi_v150_profiler/profile_runs/native_torch","torch_profiler_record_shapes":true,"torch_profiler_with_stack":false,"torch_profiler_with_memory":false,"torch_profiler_dump_cuda_time_total":true,"ignore_frontend":true}'
```

`[YOUR_UNCHANGED_BASELINE_SERVING_FLAGS]` is a **placeholder, not literal shell syntax**. Preserve the existing `--max-model-len`, `--max-num-seqs`, cache configuration, execution mode, and plugin flags. Verify `vllm serve --help` contains `--profiler-config`; a vendor fork may differ.

`--profiler-config` adds profiling overhead, so **never** use this process to claim final throughput improvements. Profiling data is used to locate bottlenecks, and the normal process is used for score validation.

## D. Collect targeted profiles using a separate diagnostic driver

Use one scenario per `/start_profile` → short burst → `/stop_profile` interval. Warming up first avoids including compilation and one-time startup costs. The diagnostic driver sends isolated `/v1/completions` requests using prompts built with the model tokenizer, and prints the server's actual token usage. This traffic is *not* substituted for the official benchmark.

```bash
cd /root/bi_v150_profiler

# Long-context PREFILL diagnostic: 16K input, 1 generated token.
python profile_burst.py --input-tokens 16384 --output-tokens 1 \
  --concurrency 1 --num-requests 2 --warmup-requests 1 \
  --out profile_runs/diagnostic_16k_prefill.json

# Long-context DECODE diagnostic: same input, 128 output tokens.
python profile_burst.py --input-tokens 16384 --output-tokens 128 \
  --concurrency 1 --num-requests 2 --warmup-requests 1 \
  --out profile_runs/diagnostic_16k_decode.json

# Short-context controls.
python profile_burst.py --input-tokens 4096 --output-tokens 1 \
  --concurrency 1 --num-requests 2 --warmup-requests 1 \
  --out profile_runs/diagnostic_4k_prefill.json
python profile_burst.py --input-tokens 4096 --output-tokens 128 \
  --concurrency 1 --num-requests 2 --warmup-requests 1 \
  --out profile_runs/diagnostic_4k_decode.json
```

Next, inspect how operator cost scales at a small batch size representative of continuous batching:

```bash
# Additional 16K decode trace at concurrency 4. Profile only after the single-sequence runs.
python profile_burst.py --input-tokens 16384 --output-tokens 128 \
  --concurrency 4 --num-requests 4 --warmup-requests 2 \
  --out profile_runs/diagnostic_16k_decode_c4.json
```

If maximum model length does not allow input+output tokens, this will fail; do not silently change `--max-model-len` during comparisons. The prompt token count may deviate by a few tokens after decode/re-encode; both tokenizer-side and serving-side counts are recorded. To force exact request token lengths, use `/tokenize`-produced token IDs with the *local* plugin operator-profile diagnostic utility, if installed (see Section F).

Save each scenario's native trace files under a different directory or snapshot the newly produced files immediately after the `/stop_profile` call. Some builds overwrite a fixed summary table filename; avoid accidentally mixing 4K and 16K trace windows. Traces can be very large; use short windows.

## E. Rank individual GPU kernels

```bash
find profile_runs/native_torch -type f \( -name '*.pt.trace.json' -o -name '*.pt.trace.json.gz' \)
python trace_report.py /full/path/to/your/rank0.pt.trace.json.gz \
  --top 35 --out-csv profile_runs/hot_kernels.csv
```

Classification by kernel name is heuristic. The GPU timeline is more useful than a summed-duration rank list when streams overlap or when CPU↔GPU gaps suppress throughput. Open the trace in https://ui.perfetto.dev (for sensitive traces, verify whether uploading traces is allowed by your environment).

Typical investigation criteria:

| Observation | Investigate | Optimization intervention (only after evidence) |
| --- | --- | --- |
| Attention/GQA kernels dominate 16K decode | KV load coalescing, page table traversal, occupancy | Rewrite/tune the identified attention kernel |
| GEMM kernels dominate in all scenarios | matrix shapes, occupancy, tiling, tensor-core use | Optimize kernel tiling / fusion while keeping dtype |
| Norm/RoPE/pointwise dominate via huge invocation count | launch overhead, intermediate tensors | Fuse proven hot elementwise kernels |
| Long idle gaps between GPU kernels | scheduler, CPU, sync, allocator stalls | Optimize actual scheduling/launch path supported by trace |
| Many waiting requests and near-full cache | KV capacity, preemption, active sequences | Optimize memory layout/access and legal scheduling overhead |

## F. Optional: use the plugin's existing detailed operator extractor

The upstream FlagOS plugin repository documents an `operator_profile/` suite that creates `operator_list.csv`, `kernel_time.csv`, `kernel_shape_dtype.csv`, and `summary.json`. This is often better than simple regex kernel grouping because it attempts ATen/custom operator attribution. **Only use it if those scripts already exist in your installed checkout**; do not merge the latest framework branch merely to obtain profiler tools.

```bash
if test -f /workspace/vllm-plugin-FL/tools/operator_profile/extract_operator_shapes.py; then
  python /workspace/vllm-plugin-FL/tools/operator_profile/extract_operator_shapes.py \
    --trace-dir /root/bi_v150_profiler/profile_runs/native_torch \
    --output-dir /root/bi_v150_profiler/profile_runs/operator_details
  head -30 /root/bi_v150_profiler/profile_runs/operator_details/kernel_time.csv
else
  echo 'Plugin operator extractor not present; use trace_report.py.'
fi
```

Link: https://github.com/flagos-ai/vllm-plugin-FL/tree/main/tools/operator_profile

## G. Judge true speedup: use the same UNMODIFIED benchmark outside profiling

With profiling disabled, re-run the exact same official baseline and candidate workloads. If two compatible CSVs contain the header shown in your `run_4k16K_benchmark.txt`:

```bash
python compare_bench.py original_baseline.csv optimized_candidate.csv --drop-first
```

`compare_bench.py` reports `(input+output)/elapsed` total tok/s speedup and generated-only output tok/s speedup. Its optional `--drop-first` is **post-processing**, applied symmetrically, and does not modify benchmark runs. Do not change the competition's score accounting based on this local report; use their prescribed statistic for final validation.

Main score metric formula:

`total_tokens_per_second = (total_input_tokens + total_output_tokens) / benchmark_duration_s`

Report separate speedup for 4K and 16K, identify the operator actually changed, and track the same source revision, hardware and model configuration. Accuracy testing comes after selecting the fastest meaningful candidates.

## Safety and scope

- Native PyTorch trace support may vary on CoreX; GPU events must be verified in the small capability test.
- Do not assume NVIDIA `nsys`/`ncu`/CUPTI works on Iluvatar despite `torch.cuda` working.
- Capturing traces changes runtime overhead. Do not compare scores from a profiled run to an unprofiled run.
- `--enforce-eager` changes the execution mode; do not use it for the official comparison if baseline uses graph mode. A separate eager diagnostic is possible, but label results accordingly.
- Do not use quantization, speculative decoding, direct framework merges, benchmark-script tweaks, or unoptimized operator substitutions.
