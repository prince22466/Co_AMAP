#!/usr/bin/env bash
# Read-only candidate file/dispatch discovery, NOT proof an implementation is invoked.
set -euo pipefail
OUT="${1:-./profile_runs/dispatch_candidates.txt}"
mkdir -p "$(dirname "$OUT")"
{
python - <<'PY'
import importlib.util
for m in ('vllm','vllm_fl','flag_gems','flagtree'):
 try:
  sp=importlib.util.find_spec(m)
  print(m,sp.origin if sp else '<missing>')
 except Exception as e:print(m,'not locatable:',repr(e))
PY
for root in /usr/local/lib/python3.12/site-packages/vllm_fl \
            /usr/local/lib/python3.12/site-packages/flag_gems \
            /usr/local/lib/python3.12/site-packages/vllm/attention \
            /workspace/vllm-plugin-FL/vllm_fl; do
 if [[ -d "$root" ]]; then
   echo "==== $root ====" 
   if command -v rg >/dev/null 2>&1; then
     rg -n --glob '*.py' -m 2 'get_attn_backend|class.*Attention|paged_attention|reshape_and_cache|flash_attn|rms_norm|rotary_embedding|grouped_gemm|VLLM_FL_DISPATCH_DEBUG' "$root" | head -160 || true
   else
     grep -R -n -E --include='*.py' 'get_attn_backend|paged_attention|reshape_and_cache|flash_attn|rms_norm|rotary_embedding' "$root" | head -160 || true
   fi
 fi
done
} > "$OUT" 2>&1
printf 'Candidate source locations saved to %s\n' "$OUT"
echo 'Note: static source search is not evidence of runtime kernel choice; corroborate with trace and dispatch DEBUG logs.'
