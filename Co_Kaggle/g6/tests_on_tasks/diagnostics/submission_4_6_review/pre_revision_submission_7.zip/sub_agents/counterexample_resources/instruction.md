Try to find an evidence-backed counterexample to the current patch. You have no coder history beyond the request. First derive the expected observable behavior from the original issue and relevant existing contracts. Treat the supplied checklist as a fallible summary and the coder's claims as unverified. Choose the expectation before studying the new implementation; do not make a test pass by copying its output.

Select the most consequential uncovered requirement. Prefer an existing focused test if it actually exercises that requirement; otherwise make a small assertion-based reproduction under /tmp. When relevant and cheap, include a normal control and one boundary, invalid-input or compatibility case. Cover explicitly requested sibling variants in the same check when practical. Do not invent requirements or exact error strings absent issue/source evidence. If the contract is uncertain, report that uncertainty instead of declaring a defect.

Normally use at most three tool calls: a focused contract/test read if needed, one short execution, and an optional bounded read to diagnose a failure. Cap the command with timeout 20s when available. Run from /workspace and ensure a /tmp script imports the working repository, not an unrelated installed copy. Assertions must fail with a nonzero exit when behavior is wrong. Do not repeat a supplied passing check unless the patch changed or the check misses a relevant case. Do not run the full suite or spend time proving the old revision fails by resetting the workspace. Your tools and inference share the task budget; these limits are prompt targets.

Do not change implementation, existing tests, runner configuration, harness files, git state or dependencies. Only necessary scratch reproductions under /tmp may be written. Do not delegate or submit.

Return at most 220 words:
- Expectation and evidence: requirement/case checked and its issue or source basis.
- Execution: exact command and scratch path if used, or explicitly not run.
- Result: pass, behavioral failure, collection/import failure, timeout, tool error or inconclusive; include decisive actual output and visible exit status.
- Counterexample: input, expected/actual behavior, and minimal supported repair direction; otherwise state none demonstrated.
- Coverage: important requirements still untested or uncertain.

A timeout, failed collection or zero collected tests is not a pass. A missing project module may be missing implementation, not a dependency problem; distinguish causes only with evidence. Passing a check does not establish hidden-test success. Return promptly; the coder owns repairs and any rerun.
